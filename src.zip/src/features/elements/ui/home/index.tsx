"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { SearchParams } from "@/types";
import SearchComponent from "./SearchComponent";
import CardsPagination from "@/components/CardsPagination";
import SkeletonGrid from "@/components/SkeletonGrid";
import { ElementCard } from "@/features/elements/ui";
import { formatDate, truncateText } from "@/utils";
import type { ElementDTO } from "@/features/elements/dto/element.dto";
import { trackEvent } from "@/lib/analytics/gtag";
import { ANALYTICS_EVENTS } from "@/lib/analytics/events";

export default function HomeClientPage({
  initialElements,
  initialTotal,
  initialError,
  initialParams,
  basePath = "/",
}: {
  initialElements: ElementDTO[];
  initialTotal: number;
  initialError?: string;
  initialParams: SearchParams;
  basePath?: string;
}) {
  const router = useRouter();

  // Local state for UI controls
  const [localSearch, setLocalSearch] = useState(initialParams.q || "");
  const [exactMatch, setExactMatch] = useState(
    initialParams.exactMatch === "true",
  );

  const [mainCats, setMainCats] = useState<string[]>(
    Array.isArray(initialParams.mainCat)
      ? initialParams.mainCat
      : initialParams.mainCat
        ? [initialParams.mainCat]
        : [],
  );

  const [secCats, setSecCats] = useState<string[]>(
    Array.isArray(initialParams.secCat)
      ? initialParams.secCat
      : initialParams.secCat
        ? [initialParams.secCat]
        : [],
  );

  const [currentPage, setCurrentPage] = useState(
    parseInt(initialParams.page || "1", 10),
  );

  const [isDirty, setIsDirty] = useState(false); // Tracks if params have changed

  // Data and UI states
  const [elements, setElements] = useState<ElementDTO[]>(initialElements);
  const [total, setTotal] = useState(initialTotal);
  const [error, setError] = useState<string | undefined>(initialError);
  const [isLoading, setIsLoading] = useState(false);

  // Pagination derived values
  const PAGE_SIZE = 12; // IMPORTANT: keep in sync with server search default
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  // Build URL parameters from current state
  const updateUrlParams = (
    page: number,
    query: string,
    mainCats: string[],
    secCats: string[],
    exactMatch: boolean,
  ) => {
    const params = new URLSearchParams();
    if (query.trim()) params.set("q", query.trim());
    mainCats.forEach((c) => params.append("mainCat", c));
    secCats.forEach((c) => params.append("secCat", c));
    params.set("page", page.toString());
    params.set("exactMatch", exactMatch.toString());
    router.push(`${basePath}?${params.toString()}`); // Trigger server re-render
  };

  // Handle search button click
  const handleSearch = () => {
    setIsLoading(true);
    const newPage = 1;
    setCurrentPage(newPage);

    trackEvent(ANALYTICS_EVENTS.SEARCH_USED, {
      query: localSearch.trim() || "(empty)",
      exact_match: exactMatch,
      main_categories: mainCats.join(",") || "(none)",
      secondary_categories: secCats.join(",") || "(none)",
      page: newPage,
    });

    updateUrlParams(newPage, localSearch, mainCats, secCats, exactMatch);
    setIsDirty(false);
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setIsLoading(true);
    setCurrentPage(page);

    trackEvent(ANALYTICS_EVENTS.PAGINATION_CLICKED, {
      page,
      query: localSearch.trim() || "(empty)",
      exact_match: exactMatch,
    });

    updateUrlParams(page, localSearch, mainCats, secCats, exactMatch);
    setIsDirty(false);
  };

  // Handle category changes (local state only)
  const handleCategoryChange = (
    newMainCats: string[],
    newSecCats: string[],
  ) => {
    setMainCats(newMainCats);
    setSecCats(newSecCats);
    setIsDirty(true); // Mark as dirty when categories change
  };

  // Sync state with server props when they change
  useEffect(() => {
    setElements(initialElements);
    setTotal(initialTotal);
    setError(initialError);
    setIsLoading(false);
    setIsDirty(false); // Reset dirty state after server update
  }, [initialElements, initialTotal, initialError]);

  // Mark as dirty when search query or exact match changes
  useEffect(() => {
    setIsDirty(true);
  }, [localSearch, exactMatch]);

  // Clamp current page if totalPages shrinks (prevents out-of-range pagination)
  useEffect(() => {
    if (currentPage > totalPages) {
      handlePageChange(totalPages);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [totalPages]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-500 p-2 sm:p-4 md:p-8 rounded-md">
      <SearchComponent
        searchQuery={localSearch}
        setSearchQuery={setLocalSearch}
        exactMatch={exactMatch}
        setExactMatch={setExactMatch}
        mainCats={mainCats}
        secCats={secCats}
        onCategoryChange={handleCategoryChange}
        onSearch={handleSearch}
        isLoading={isLoading}
        isDirty={isDirty}
      />

      <div className="max-w-7xl mx-auto">
        <div className="mb-4 flex items-center justify-between gap-4">
          <h3 className="text-xl font-semibold uppercase">Items</h3>
          <p className="text-sm text-gray-500">{total} result{total === 1 ? "" : "s"}</p>
        </div>

        {isLoading ? (
          <SkeletonGrid count={9} />
        ) : (
          <>
            {error && (
              <div className="text-center py-12 text-red-500 uppercase">
                Error: {error}
              </div>
            )}

            {elements.length > 0 ? (
              <CardsPagination
                items={elements}
                itemsByRow={2}
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
                renderItem={(element) => (
                  <ElementCard
                    key={element.id}
                    element={element}
                    status="preview"
                    formatDate={formatDate}
                    truncateText={truncateText}
                  />
                )}
              />
            ) : (
              <div className="text-center py-12 text-gray-500 uppercase">
                No elements found matching your criteria
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
